import sys
import os

sys.path.insert(0, os.path.abspath(r'..'))
sys.path.insert(0, os.path.abspath(r'.'))

